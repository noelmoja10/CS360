# Project Two does not enable code shrinking; this file is reserved for release rules.
