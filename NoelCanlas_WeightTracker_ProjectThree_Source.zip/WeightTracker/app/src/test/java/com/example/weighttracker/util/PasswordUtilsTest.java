package com.example.weighttracker.util;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class PasswordUtilsTest {
    @Test
    public void hashAndVerifyPassword() {
        String salt = PasswordUtils.createSalt();
        String hash = PasswordUtils.hashPassword("correct-password", salt);

        assertTrue(PasswordUtils.verifyPassword("correct-password", salt, hash));
        assertFalse(PasswordUtils.verifyPassword("wrong-password", salt, hash));
    }
}
