package com.example.weighttracker.util;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.format.ResolverStyle;
import java.util.Locale;

public final class DateUtils {
    private static final DateTimeFormatter DISPLAY_DATE = DateTimeFormatter
            .ofPattern("MM/dd/uuuu", Locale.US)
            .withResolverStyle(ResolverStyle.STRICT);

    private DateUtils() {
    }

    public static String normalizeToIso(String value) {
        String trimmed = value == null ? "" : value.trim();
        if (trimmed.isEmpty()) {
            throw new DateTimeParseException("Date is required", trimmed, 0);
        }

        try {
            return LocalDate.parse(trimmed, DISPLAY_DATE).toString();
        } catch (DateTimeParseException ignored) {
            return LocalDate.parse(trimmed, DateTimeFormatter.ISO_LOCAL_DATE).toString();
        }
    }

    public static String formatForDisplay(String isoDate) {
        return LocalDate.parse(isoDate, DateTimeFormatter.ISO_LOCAL_DATE).format(DISPLAY_DATE);
    }

    public static String todayIso() {
        return LocalDate.now().toString();
    }

    public static String todayDisplay() {
        return LocalDate.now().format(DISPLAY_DATE);
    }
}
