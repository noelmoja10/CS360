# Third-Party Notices

## Inter

This project bundles Inter 4.1 by Rasmus Andersson for the Android UI typography.

Source: https://rsms.me/inter/download/

License: SIL Open Font License 1.1. See `INTER_LICENSE.txt` for the bundled license text.
