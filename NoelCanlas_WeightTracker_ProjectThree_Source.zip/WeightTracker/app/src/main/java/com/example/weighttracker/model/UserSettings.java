package com.example.weighttracker.model;

public final class UserSettings {
    private final long userId;
    private final double goalWeight;
    private final String phoneNumber;
    private final boolean smsEnabled;
    private final boolean goalAlertSent;

    public UserSettings(
            long userId,
            double goalWeight,
            String phoneNumber,
            boolean smsEnabled,
            boolean goalAlertSent) {
        this.userId = userId;
        this.goalWeight = goalWeight;
        this.phoneNumber = phoneNumber == null ? "" : phoneNumber;
        this.smsEnabled = smsEnabled;
        this.goalAlertSent = goalAlertSent;
    }

    public long getUserId() {
        return userId;
    }

    public double getGoalWeight() {
        return goalWeight;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public boolean isSmsEnabled() {
        return smsEnabled;
    }

    public boolean isGoalAlertSent() {
        return goalAlertSent;
    }
}
