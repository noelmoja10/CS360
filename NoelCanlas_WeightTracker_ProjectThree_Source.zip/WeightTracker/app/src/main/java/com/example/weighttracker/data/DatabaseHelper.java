package com.example.weighttracker.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteConstraintException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.weighttracker.model.UserSettings;
import com.example.weighttracker.model.WeightRecord;
import com.example.weighttracker.util.PasswordUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "weight_progress.db";
    private static final int DATABASE_VERSION = 2;

    private static final String TABLE_USERS = "users";
    private static final String TABLE_SETTINGS = "user_settings";
    private static final String TABLE_WEIGHTS = "weight_records";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onConfigure(SQLiteDatabase database) {
        super.onConfigure(database);
        database.setForeignKeyConstraintsEnabled(true);
    }

    @Override
    public void onCreate(SQLiteDatabase database) {
        database.execSQL(
                "CREATE TABLE " + TABLE_USERS + " ("
                        + "id INTEGER PRIMARY KEY AUTOINCREMENT, "
                        + "username TEXT NOT NULL UNIQUE, "
                        + "first_name TEXT NOT NULL DEFAULT '', "
                        + "last_name TEXT NOT NULL DEFAULT '', "
                        + "email TEXT NOT NULL DEFAULT '', "
                        + "phone_number TEXT NOT NULL DEFAULT '', "
                        + "password_hash TEXT NOT NULL, "
                        + "password_salt TEXT NOT NULL, "
                        + "created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP"
                        + ")");

        database.execSQL(
                "CREATE TABLE " + TABLE_SETTINGS + " ("
                        + "user_id INTEGER PRIMARY KEY, "
                        + "goal_weight REAL NOT NULL DEFAULT 150.0, "
                        + "phone_number TEXT NOT NULL DEFAULT '', "
                        + "sms_enabled INTEGER NOT NULL DEFAULT 0, "
                        + "goal_alert_sent INTEGER NOT NULL DEFAULT 0, "
                        + "FOREIGN KEY(user_id) REFERENCES " + TABLE_USERS + "(id) ON DELETE CASCADE"
                        + ")");

        database.execSQL(
                "CREATE TABLE " + TABLE_WEIGHTS + " ("
                        + "id INTEGER PRIMARY KEY AUTOINCREMENT, "
                        + "user_id INTEGER NOT NULL, "
                        + "entry_date TEXT NOT NULL, "
                        + "weight REAL NOT NULL CHECK(weight > 0), "
                        + "notes TEXT NOT NULL DEFAULT '', "
                        + "created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, "
                        + "FOREIGN KEY(user_id) REFERENCES " + TABLE_USERS + "(id) ON DELETE CASCADE, "
                        + "UNIQUE(user_id, entry_date)"
                        + ")");

        database.execSQL(
                "CREATE INDEX idx_weight_user_date ON " + TABLE_WEIGHTS
                        + "(user_id, entry_date DESC)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase database, int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            database.execSQL("ALTER TABLE " + TABLE_USERS
                    + " ADD COLUMN first_name TEXT NOT NULL DEFAULT ''");
            database.execSQL("ALTER TABLE " + TABLE_USERS
                    + " ADD COLUMN last_name TEXT NOT NULL DEFAULT ''");
            database.execSQL("ALTER TABLE " + TABLE_USERS
                    + " ADD COLUMN email TEXT NOT NULL DEFAULT ''");
            database.execSQL("ALTER TABLE " + TABLE_USERS
                    + " ADD COLUMN phone_number TEXT NOT NULL DEFAULT ''");
            database.execSQL("UPDATE " + TABLE_USERS
                    + " SET email = username WHERE email = ''");
        }
    }

    public long createUser(String username, String password) {
        return createUser("", "", username, "", password);
    }

    public long createUser(
            String firstName,
            String lastName,
            String email,
            String phoneNumber,
            String password) {
        String normalizedUsername = normalizeUsername(email);
        String normalizedPhone = phoneNumber == null ? "" : phoneNumber.trim();
        String salt = PasswordUtils.createSalt();
        String hash = PasswordUtils.hashPassword(password, salt);
        SQLiteDatabase database = getWritableDatabase();

        database.beginTransaction();
        try {
            ContentValues userValues = new ContentValues();
            userValues.put("username", normalizedUsername);
            userValues.put("first_name", firstName == null ? "" : firstName.trim());
            userValues.put("last_name", lastName == null ? "" : lastName.trim());
            userValues.put("email", normalizedUsername);
            userValues.put("phone_number", normalizedPhone);
            userValues.put("password_hash", hash);
            userValues.put("password_salt", salt);
            long userId = database.insertOrThrow(TABLE_USERS, null, userValues);

            ContentValues settingsValues = new ContentValues();
            settingsValues.put("user_id", userId);
            settingsValues.put("phone_number", normalizedPhone);
            database.insertOrThrow(TABLE_SETTINGS, null, settingsValues);

            database.setTransactionSuccessful();
            return userId;
        } catch (SQLiteConstraintException exception) {
            return -1L;
        } finally {
            database.endTransaction();
        }
    }

    public long authenticateUser(String username, String password) {
        String[] columns = {"id", "password_hash", "password_salt"};
        String[] arguments = {normalizeUsername(username)};

        try (Cursor cursor = getReadableDatabase().query(
                TABLE_USERS,
                columns,
                "username = ?",
                arguments,
                null,
                null,
                null)) {
            if (!cursor.moveToFirst()) {
                return -1L;
            }

            String hash = cursor.getString(cursor.getColumnIndexOrThrow("password_hash"));
            String salt = cursor.getString(cursor.getColumnIndexOrThrow("password_salt"));
            if (!PasswordUtils.verifyPassword(password, salt, hash)) {
                return -1L;
            }
            return cursor.getLong(cursor.getColumnIndexOrThrow("id"));
        }
    }

    public long insertWeightRecord(
            long userId,
            String entryDate,
            double weight,
            String notes) {
        ContentValues values = weightValues(userId, entryDate, weight, notes);
        try {
            return getWritableDatabase().insertOrThrow(TABLE_WEIGHTS, null, values);
        } catch (SQLiteConstraintException exception) {
            return -1L;
        }
    }

    public boolean updateWeightRecord(
            long recordId,
            long userId,
            String entryDate,
            double weight,
            String notes) {
        ContentValues values = weightValues(userId, entryDate, weight, notes);
        try {
            int updated = getWritableDatabase().update(
                    TABLE_WEIGHTS,
                    values,
                    "id = ? AND user_id = ?",
                    new String[]{String.valueOf(recordId), String.valueOf(userId)});
            return updated == 1;
        } catch (SQLiteConstraintException exception) {
            return false;
        }
    }

    public boolean deleteWeightRecord(long recordId, long userId) {
        int deleted = getWritableDatabase().delete(
                TABLE_WEIGHTS,
                "id = ? AND user_id = ?",
                new String[]{String.valueOf(recordId), String.valueOf(userId)});
        return deleted == 1;
    }

    public WeightRecord getWeightRecord(long recordId, long userId) {
        try (Cursor cursor = getReadableDatabase().query(
                TABLE_WEIGHTS,
                null,
                "id = ? AND user_id = ?",
                new String[]{String.valueOf(recordId), String.valueOf(userId)},
                null,
                null,
                null)) {
            return cursor.moveToFirst() ? readWeightRecord(cursor) : null;
        }
    }

    public List<WeightRecord> getWeightRecords(long userId) {
        return getWeightRecords(userId, 0);
    }

    public List<WeightRecord> getWeightRecords(long userId, int limit) {
        List<WeightRecord> records = new ArrayList<>();
        String limitText = limit > 0 ? String.valueOf(limit) : null;

        try (Cursor cursor = getReadableDatabase().query(
                TABLE_WEIGHTS,
                null,
                "user_id = ?",
                new String[]{String.valueOf(userId)},
                null,
                null,
                "entry_date DESC, id DESC",
                limitText)) {
            while (cursor.moveToNext()) {
                records.add(readWeightRecord(cursor));
            }
        }
        return records;
    }

    public UserSettings getUserSettings(long userId) {
        try (Cursor cursor = getReadableDatabase().query(
                TABLE_SETTINGS,
                null,
                "user_id = ?",
                new String[]{String.valueOf(userId)},
                null,
                null,
                null)) {
            if (cursor.moveToFirst()) {
                return new UserSettings(
                        userId,
                        cursor.getDouble(cursor.getColumnIndexOrThrow("goal_weight")),
                        cursor.getString(cursor.getColumnIndexOrThrow("phone_number")),
                        cursor.getInt(cursor.getColumnIndexOrThrow("sms_enabled")) == 1,
                        cursor.getInt(cursor.getColumnIndexOrThrow("goal_alert_sent")) == 1);
            }
        }

        ContentValues values = new ContentValues();
        values.put("user_id", userId);
        getWritableDatabase().insert(TABLE_SETTINGS, null, values);
        return new UserSettings(userId, 150.0, "", false, false);
    }

    public void updateGoalWeight(long userId, double goalWeight) {
        UserSettings settings = getUserSettings(userId);
        ContentValues values = new ContentValues();
        values.put("goal_weight", goalWeight);
        if (Double.compare(settings.getGoalWeight(), goalWeight) != 0) {
            values.put("goal_alert_sent", 0);
        }
        getWritableDatabase().update(
                TABLE_SETTINGS,
                values,
                "user_id = ?",
                new String[]{String.valueOf(userId)});
    }

    public void updateSmsSettings(long userId, String phoneNumber, boolean enabled) {
        ContentValues values = new ContentValues();
        values.put("phone_number", phoneNumber == null ? "" : phoneNumber.trim());
        values.put("sms_enabled", enabled ? 1 : 0);
        getWritableDatabase().update(
                TABLE_SETTINGS,
                values,
                "user_id = ?",
                new String[]{String.valueOf(userId)});
    }

    public void setGoalAlertSent(long userId, boolean sent) {
        ContentValues values = new ContentValues();
        values.put("goal_alert_sent", sent ? 1 : 0);
        getWritableDatabase().update(
                TABLE_SETTINGS,
                values,
                "user_id = ?",
                new String[]{String.valueOf(userId)});
    }

    private static ContentValues weightValues(
            long userId,
            String entryDate,
            double weight,
            String notes) {
        ContentValues values = new ContentValues();
        values.put("user_id", userId);
        values.put("entry_date", entryDate);
        values.put("weight", weight);
        values.put("notes", notes == null ? "" : notes.trim());
        return values;
    }

    private static WeightRecord readWeightRecord(Cursor cursor) {
        return new WeightRecord(
                cursor.getLong(cursor.getColumnIndexOrThrow("id")),
                cursor.getLong(cursor.getColumnIndexOrThrow("user_id")),
                cursor.getString(cursor.getColumnIndexOrThrow("entry_date")),
                cursor.getDouble(cursor.getColumnIndexOrThrow("weight")),
                cursor.getString(cursor.getColumnIndexOrThrow("notes")));
    }

    private static String normalizeUsername(String username) {
        return username == null ? "" : username.trim().toLowerCase(Locale.US);
    }
}
