package com.example.weighttracker;

import android.Manifest;
import android.app.AlertDialog;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.InputType;
import android.util.Patterns;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.ComponentActivity;
import androidx.activity.OnBackPressedCallback;

import com.example.weighttracker.data.DatabaseHelper;
import com.example.weighttracker.model.UserSettings;
import com.example.weighttracker.model.WeightRecord;
import com.example.weighttracker.util.DateUtils;
import com.example.weighttracker.util.SmsNotifier;

import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.Locale;

public class MainActivity extends ComponentActivity {
    private static final int SMS_PERMISSION_REQUEST_CODE = 3602;
    private static final long NO_ID = -1L;
    private static final String STATE_USER_ID = "current_user_id";
    private static final String STATE_SCREEN = "current_screen";
    private static final String STATE_EDIT_RECORD_ID = "edit_record_id";

    private DatabaseHelper databaseHelper;
    private long currentUserId = NO_ID;
    private long editingRecordId = NO_ID;
    private String pendingPhoneNumber = "";
    private Screen currentScreen = Screen.LOGIN;

    private enum Screen {
        LOGIN,
        CREATE_ACCOUNT,
        HOME,
        HISTORY,
        ADD_WEIGHT,
        SMS
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        databaseHelper = new DatabaseHelper(this);
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                handleBackNavigation();
            }
        });

        if (savedInstanceState != null) {
            currentUserId = savedInstanceState.getLong(STATE_USER_ID, NO_ID);
            editingRecordId = savedInstanceState.getLong(STATE_EDIT_RECORD_ID, NO_ID);
            String screenName = savedInstanceState.getString(STATE_SCREEN, Screen.LOGIN.name());
            try {
                currentScreen = Screen.valueOf(screenName);
            } catch (IllegalArgumentException exception) {
                currentScreen = Screen.LOGIN;
            }
        }

        restoreScreen();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putLong(STATE_USER_ID, currentUserId);
        outState.putLong(STATE_EDIT_RECORD_ID, editingRecordId);
        outState.putString(STATE_SCREEN, currentScreen.name());
    }

    @Override
    protected void onDestroy() {
        databaseHelper.close();
        super.onDestroy();
    }

    private void restoreScreen() {
        if (currentUserId == NO_ID) {
            if (currentScreen == Screen.CREATE_ACCOUNT) {
                showCreateAccountScreen();
            } else {
                showLoginScreen();
            }
            return;
        }

        switch (currentScreen) {
            case HISTORY:
                showHistoryScreen();
                break;
            case ADD_WEIGHT:
                showAddWeightScreen(editingRecordId);
                break;
            case SMS:
                showSmsPermissionScreen();
                break;
            case HOME:
            default:
                showHomeScreen();
                break;
        }
    }

    private void showLoginScreen() {
        currentScreen = Screen.LOGIN;
        currentUserId = NO_ID;
        editingRecordId = NO_ID;
        setContentView(R.layout.activity_login);

        EditText usernameEditText = findViewById(R.id.usernameEditText);
        EditText passwordEditText = findViewById(R.id.passwordEditText);
        ImageButton passwordToggleButton = findViewById(R.id.loginPasswordToggleButton);
        configurePasswordToggle(passwordEditText, passwordToggleButton);

        findViewById(R.id.loginButton).setOnClickListener(view -> {
            String username = normalizeEmail(usernameEditText.getText().toString());
            String password = passwordEditText.getText().toString();
            if (!validateLogin(usernameEditText, passwordEditText, username, password)) {
                return;
            }

            long userId = databaseHelper.authenticateUser(username, password);
            if (userId == NO_ID) {
                passwordEditText.setError("Username or password is incorrect");
                return;
            }

            currentUserId = userId;
            Toast.makeText(this, "Login successful", Toast.LENGTH_SHORT).show();
            showHomeScreen();
        });

        findViewById(R.id.createAccountButton).setOnClickListener(view -> showCreateAccountScreen());
    }

    private void showCreateAccountScreen() {
        currentScreen = Screen.CREATE_ACCOUNT;
        currentUserId = NO_ID;
        editingRecordId = NO_ID;
        setContentView(R.layout.activity_create_account);

        EditText firstNameEditText = findViewById(R.id.firstNameEditText);
        EditText lastNameEditText = findViewById(R.id.lastNameEditText);
        EditText emailEditText = findViewById(R.id.accountEmailEditText);
        EditText phoneEditText = findViewById(R.id.accountPhoneEditText);
        EditText passwordEditText = findViewById(R.id.createPasswordEditText);
        EditText confirmPasswordEditText = findViewById(R.id.confirmPasswordEditText);

        configurePasswordToggle(
                passwordEditText,
                findViewById(R.id.createPasswordToggleButton));
        configurePasswordToggle(
                confirmPasswordEditText,
                findViewById(R.id.confirmPasswordToggleButton));

        findViewById(R.id.submitCreateAccountButton).setOnClickListener(view -> {
            String firstName = firstNameEditText.getText().toString().trim();
            String lastName = lastNameEditText.getText().toString().trim();
            String email = normalizeEmail(emailEditText.getText().toString());
            String phone = normalizePhoneNumber(phoneEditText.getText().toString());
            String password = passwordEditText.getText().toString();
            String confirmPassword = confirmPasswordEditText.getText().toString();

            if (!validateCreateAccount(
                    firstNameEditText,
                    lastNameEditText,
                    emailEditText,
                    phoneEditText,
                    passwordEditText,
                    confirmPasswordEditText,
                    firstName,
                    lastName,
                    email,
                    phone,
                    password,
                    confirmPassword)) {
                return;
            }

            long userId = databaseHelper.createUser(
                    firstName,
                    lastName,
                    email,
                    phone,
                    password);
            if (userId == NO_ID) {
                emailEditText.setError("An account already exists for this email");
                return;
            }

            currentUserId = userId;
            Toast.makeText(this, "Account created", Toast.LENGTH_SHORT).show();
            showHomeScreen();
        });

        findViewById(R.id.backToLoginButton).setOnClickListener(view -> showLoginScreen());
    }

    private boolean validateLogin(
            EditText emailEditText,
            EditText passwordEditText,
            String email,
            String password) {
        emailEditText.setError(null);
        passwordEditText.setError(null);

        if (!isValidEmail(email)) {
            emailEditText.setError("Enter a valid email address");
            return false;
        }
        if (password.isEmpty()) {
            passwordEditText.setError("Password is required");
            return false;
        }
        return true;
    }

    private boolean validateCreateAccount(
            EditText firstNameEditText,
            EditText lastNameEditText,
            EditText emailEditText,
            EditText phoneEditText,
            EditText passwordEditText,
            EditText confirmPasswordEditText,
            String firstName,
            String lastName,
            String email,
            String phone,
            String password,
            String confirmPassword) {
        firstNameEditText.setError(null);
        lastNameEditText.setError(null);
        emailEditText.setError(null);
        phoneEditText.setError(null);
        passwordEditText.setError(null);
        confirmPasswordEditText.setError(null);

        if (firstName.length() < 2) {
            firstNameEditText.setError("Enter your first name");
            return false;
        }
        if (lastName.length() < 2) {
            lastNameEditText.setError("Enter your last name");
            return false;
        }
        if (!isValidEmail(email)) {
            emailEditText.setError("Enter a valid email address");
            return false;
        }
        if (!isValidPhoneNumber(phone)) {
            phoneEditText.setError("Enter 7 to 15 digits, with an optional +");
            return false;
        }
        if (!isValidPassword(password)) {
            passwordEditText.setError("Use 8+ characters with a letter and number");
            return false;
        }
        if (!password.equals(confirmPassword)) {
            confirmPasswordEditText.setError("Passwords do not match");
            return false;
        }
        return true;
    }

    private void showHomeScreen() {
        requireLoggedInUser();
        currentScreen = Screen.HOME;
        editingRecordId = NO_ID;
        setContentView(R.layout.activity_home);

        EditText quickWeightEditText = findViewById(R.id.quickWeightEditText);
        findViewById(R.id.addWeightButton).setOnClickListener(view -> {
            Double weight = parsePositiveWeight(quickWeightEditText, "Enter a valid weight");
            if (weight == null) {
                return;
            }

            long recordId = databaseHelper.insertWeightRecord(
                    currentUserId,
                    DateUtils.todayIso(),
                    weight,
                    "");
            if (recordId == NO_ID) {
                quickWeightEditText.setError("A record already exists for today. Edit it in History.");
                return;
            }

            quickWeightEditText.setText("");
            Toast.makeText(this, "Weight record saved", Toast.LENGTH_SHORT).show();
            evaluateGoalAlert();
            refreshHomeScreen();
        });

        findViewById(R.id.historyButton).setOnClickListener(view -> showHistoryScreen());
        findViewById(R.id.navHomeButton).setOnClickListener(view -> refreshHomeScreen());
        findViewById(R.id.navHistoryButton).setOnClickListener(view -> showHistoryScreen());
        findViewById(R.id.navGoalButton).setOnClickListener(view -> showAddWeightScreen(NO_ID));
        findViewById(R.id.navSettingsButton).setOnClickListener(view -> showSmsPermissionScreen());
        findViewById(R.id.smsSettingsButton).setOnClickListener(view -> showAppMenu());

        refreshHomeScreen();
    }

    private void refreshHomeScreen() {
        List<WeightRecord> records = databaseHelper.getWeightRecords(currentUserId);
        UserSettings settings = databaseHelper.getUserSettings(currentUserId);
        TextView currentWeightTextView = findViewById(R.id.currentWeightTextView);
        TextView goalWeightTextView = findViewById(R.id.goalWeightTextView);
        TextView progressPercentTextView = findViewById(R.id.progressPercentTextView);
        TextView remainingWeightTextView = findViewById(R.id.remainingWeightTextView);

        goalWeightTextView.setText(formatWeight(settings.getGoalWeight()));
        if (records.isEmpty()) {
            currentWeightTextView.setText("--");
            progressPercentTextView.setText("0%");
            remainingWeightTextView.setText(R.string.progress_empty);
            updateProgressBar(0);
        } else {
            double currentWeight = records.get(0).getWeight();
            double startingWeight = records.get(records.size() - 1).getWeight();
            int progress = calculateProgress(startingWeight, currentWeight, settings.getGoalWeight());
            double remaining = Math.max(currentWeight - settings.getGoalWeight(), 0.0);

            currentWeightTextView.setText(formatWeight(currentWeight));
            progressPercentTextView.setText(String.format(Locale.US, "%d%%", progress));
            remainingWeightTextView.setText(remaining == 0.0
                    ? "Goal reached"
                    : String.format(Locale.US, "%s lbs left to goal", formatWeight(remaining)));
            updateProgressBar(progress);
        }

        populateRecentHistory(records);
    }

    private void updateProgressBar(int progress) {
        FrameLayout track = findViewById(R.id.progressTrackLayout);
        View fill = findViewById(R.id.progressFillView);
        track.post(() -> {
            int width = Math.round(track.getWidth() * (progress / 100f));
            ViewGroup.LayoutParams parameters = fill.getLayoutParams();
            parameters.width = Math.max(0, width);
            fill.setLayoutParams(parameters);
        });
    }

    private static int calculateProgress(double startingWeight, double currentWeight, double goalWeight) {
        // Weight-loss progress is measured from the earliest saved weight toward the goal.
        if (currentWeight <= goalWeight) {
            return 100;
        }
        if (startingWeight <= goalWeight || startingWeight == currentWeight) {
            return 0;
        }
        double percentage = ((startingWeight - currentWeight) / (startingWeight - goalWeight)) * 100.0;
        return (int) Math.max(0, Math.min(100, Math.round(percentage)));
    }

    private void populateRecentHistory(List<WeightRecord> records) {
        LinearLayout container = findViewById(R.id.recentHistoryContainer);
        container.removeAllViews();

        if (records.isEmpty()) {
            TextView emptyText = createBodyText("No weight records yet");
            emptyText.setPadding(0, dp(8), 0, dp(12));
            container.addView(emptyText);
            return;
        }

        int count = Math.min(4, records.size());
        for (int index = 0; index < count; index++) {
            WeightRecord record = records.get(index);
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setMinimumHeight(dp(48));

            TextView value = createBodyText(String.format(
                    Locale.US,
                    "%s - %s lbs",
                    DateUtils.formatForDisplay(record.getEntryDate()).substring(0, 5),
                    formatWeight(record.getWeight())));
            value.setTextSize(18);
            value.setLayoutParams(new LinearLayout.LayoutParams(
                    0,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    1f));
            value.setOnClickListener(view -> showAddWeightScreen(record.getId()));

            ImageButton deleteButton = createActionButton(
                    R.drawable.ic_delete,
                    "Delete weight record");
            deleteButton.setOnClickListener(view -> confirmDeleteRecord(record));

            row.addView(value);
            row.addView(deleteButton);
            container.addView(row);
        }
    }

    private void showHistoryScreen() {
        requireLoggedInUser();
        currentScreen = Screen.HISTORY;
        editingRecordId = NO_ID;
        setContentView(R.layout.activity_history);

        findViewById(R.id.historySmsButton).setOnClickListener(view -> showAppMenu());
        findViewById(R.id.addFromHistoryButton).setOnClickListener(view -> showAddWeightScreen(NO_ID));
        findViewById(R.id.backHomeFromHistoryButton).setOnClickListener(view -> showHomeScreen());
        populateHistoryGrid();
    }

    private void populateHistoryGrid() {
        TableLayout table = findViewById(R.id.weightHistoryTable);
        while (table.getChildCount() > 1) {
            table.removeViewAt(1);
        }

        List<WeightRecord> records = databaseHelper.getWeightRecords(currentUserId);
        if (records.isEmpty()) {
            TableRow emptyRow = new TableRow(this);
            TextView emptyText = createTableCell("No records yet", 362, Gravity.CENTER, false);
            TableRow.LayoutParams parameters = new TableRow.LayoutParams(dp(362), dp(64));
            parameters.span = 5;
            emptyText.setLayoutParams(parameters);
            emptyRow.addView(emptyText);
            table.addView(emptyRow);
            return;
        }

        for (int index = 0; index < records.size(); index++) {
            WeightRecord record = records.get(index);
            WeightRecord olderRecord = index + 1 < records.size() ? records.get(index + 1) : null;
            String changeText = olderRecord == null
                    ? "--"
                    : formatSignedWeight(record.getWeight() - olderRecord.getWeight());

            TableRow row = new TableRow(this);
            row.setMinimumHeight(dp(58));
            row.addView(createTableCell(
                    DateUtils.formatForDisplay(record.getEntryDate()).substring(0, 5),
                    64,
                    Gravity.CENTER,
                    false));
            row.addView(createTableCell(
                    formatWeight(record.getWeight()) + " lbs",
                    76,
                    Gravity.CENTER,
                    false));
            TextView changeCell = createTableCell(changeText, 80, Gravity.CENTER, true);
            changeCell.setTextColor(getColor(R.color.brand));
            row.addView(changeCell);

            ImageButton editButton = createTableActionButton(
                    R.drawable.ic_edit,
                    "Edit weight record",
                    58);
            editButton.setOnClickListener(view -> showAddWeightScreen(record.getId()));
            row.addView(editButton);

            ImageButton deleteButton = createTableActionButton(
                    R.drawable.ic_delete,
                    "Delete weight record",
                    84);
            deleteButton.setOnClickListener(view -> confirmDeleteRecord(record));
            row.addView(deleteButton);
            table.addView(row);
        }
    }

    private void confirmDeleteRecord(WeightRecord record) {
        new AlertDialog.Builder(this)
                .setTitle("Delete weight record?")
                .setMessage(String.format(
                        Locale.US,
                        "%s - %s lbs",
                        DateUtils.formatForDisplay(record.getEntryDate()),
                        formatWeight(record.getWeight())))
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Delete", (dialog, which) -> {
                    if (databaseHelper.deleteWeightRecord(record.getId(), currentUserId)) {
                        Toast.makeText(this, "Weight record deleted", Toast.LENGTH_SHORT).show();
                        evaluateGoalAlert();
                        if (currentScreen == Screen.HISTORY) {
                            populateHistoryGrid();
                        } else {
                            refreshHomeScreen();
                        }
                    }
                })
                .show();
    }

    private void showAddWeightScreen(long recordId) {
        requireLoggedInUser();
        currentScreen = Screen.ADD_WEIGHT;
        editingRecordId = recordId;
        setContentView(R.layout.activity_add_weight);

        EditText weightEditText = findViewById(R.id.weightEditText);
        EditText dateEditText = findViewById(R.id.dateEditText);
        EditText goalEditText = findViewById(R.id.goalEditText);
        EditText notesEditText = findViewById(R.id.notesEditText);
        Button saveWeightButton = findViewById(R.id.saveWeightButton);

        UserSettings settings = databaseHelper.getUserSettings(currentUserId);
        goalEditText.setText(formatWeight(settings.getGoalWeight()));
        dateEditText.setText(DateUtils.todayDisplay());

        if (recordId != NO_ID) {
            WeightRecord record = databaseHelper.getWeightRecord(recordId, currentUserId);
            if (record == null) {
                Toast.makeText(this, "Weight record could not be found", Toast.LENGTH_SHORT).show();
                showHistoryScreen();
                return;
            }
            weightEditText.setText(formatWeight(record.getWeight()));
            dateEditText.setText(DateUtils.formatForDisplay(record.getEntryDate()));
            notesEditText.setText(record.getNotes());
            saveWeightButton.setText(R.string.update_weight_record);
        }

        saveWeightButton.setOnClickListener(view -> saveWeightRecord(
                weightEditText,
                dateEditText,
                goalEditText,
                notesEditText));
        findViewById(R.id.backHomeFromAddButton).setOnClickListener(view -> showHomeScreen());
    }

    private void saveWeightRecord(
            EditText weightEditText,
            EditText dateEditText,
            EditText goalEditText,
            EditText notesEditText) {
        Double weight = parsePositiveWeight(weightEditText, "Enter a valid weight");
        Double goal = parsePositiveWeight(goalEditText, "Enter a valid goal weight");
        if (weight == null || goal == null) {
            return;
        }

        String entryDate;
        try {
            entryDate = DateUtils.normalizeToIso(dateEditText.getText().toString());
        } catch (DateTimeParseException exception) {
            dateEditText.setError("Use MM/DD/YYYY");
            return;
        }

        String notes = notesEditText.getText().toString();
        boolean saved;
        if (editingRecordId == NO_ID) {
            saved = databaseHelper.insertWeightRecord(
                    currentUserId,
                    entryDate,
                    weight,
                    notes) != NO_ID;
        } else {
            saved = databaseHelper.updateWeightRecord(
                    editingRecordId,
                    currentUserId,
                    entryDate,
                    weight,
                    notes);
        }

        if (!saved) {
            dateEditText.setError("A record already exists for this date");
            return;
        }

        databaseHelper.updateGoalWeight(currentUserId, goal);
        Toast.makeText(
                this,
                editingRecordId == NO_ID ? "Weight record saved" : "Weight record updated",
                Toast.LENGTH_SHORT).show();
        editingRecordId = NO_ID;
        evaluateGoalAlert();
        showHistoryScreen();
    }

    private Double parsePositiveWeight(EditText editText, String errorMessage) {
        String value = editText.getText().toString().trim();
        try {
            double number = Double.parseDouble(value);
            if (number <= 0 || number > 1_500) {
                throw new NumberFormatException("Weight outside accepted range");
            }
            editText.setError(null);
            return number;
        } catch (NumberFormatException exception) {
            editText.setError(errorMessage);
            return null;
        }
    }

    private void showSmsPermissionScreen() {
        requireLoggedInUser();
        currentScreen = Screen.SMS;
        editingRecordId = NO_ID;
        setContentView(R.layout.activity_sms_permission);

        EditText phoneNumberEditText = findViewById(R.id.phoneNumberEditText);
        UserSettings settings = databaseHelper.getUserSettings(currentUserId);
        phoneNumberEditText.setText(settings.getPhoneNumber());
        updateSmsStatusText();

        findViewById(R.id.requestPermissionButton).setOnClickListener(view -> {
            String phoneNumber = normalizePhoneNumber(phoneNumberEditText.getText().toString());
            if (!isValidPhoneNumber(phoneNumber)) {
                phoneNumberEditText.setError("Enter 7 to 15 digits, with an optional +");
                return;
            }

            pendingPhoneNumber = phoneNumber;
            databaseHelper.updateSmsSettings(currentUserId, phoneNumber, false);
            if (SmsNotifier.canSend(this)) {
                databaseHelper.updateSmsSettings(currentUserId, phoneNumber, true);
                Toast.makeText(this, "SMS reminders enabled", Toast.LENGTH_SHORT).show();
                updateSmsStatusText();
                evaluateGoalAlert();
            } else {
                requestPermissions(
                        new String[]{Manifest.permission.SEND_SMS},
                        SMS_PERMISSION_REQUEST_CODE);
            }
        });

        findViewById(R.id.declinePermissionButton).setOnClickListener(view -> {
            UserSettings currentSettings = databaseHelper.getUserSettings(currentUserId);
            databaseHelper.updateSmsSettings(
                    currentUserId,
                    currentSettings.getPhoneNumber(),
                    false);
            updateSmsStatusText();
            Toast.makeText(this, "SMS reminders are off", Toast.LENGTH_SHORT).show();
        });

        findViewById(R.id.backFromSmsButton).setOnClickListener(view -> showHomeScreen());
    }

    private void updateSmsStatusText() {
        TextView statusTextView = findViewById(R.id.permissionStatusTextView);
        UserSettings settings = databaseHelper.getUserSettings(currentUserId);
        if (!SmsNotifier.canSend(this)) {
            statusTextView.setText(R.string.sms_status_permission_denied);
        } else if (!settings.isSmsEnabled()) {
            statusTextView.setText(R.string.sms_status_disabled);
        } else {
            statusTextView.setText(getString(
                    R.string.sms_status_enabled,
                    settings.getPhoneNumber()));
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != SMS_PERMISSION_REQUEST_CODE || currentUserId == NO_ID) {
            return;
        }

        boolean granted = grantResults.length > 0
                && grantResults[0] == PackageManager.PERMISSION_GRANTED;
        UserSettings settings = databaseHelper.getUserSettings(currentUserId);
        String phoneNumber = pendingPhoneNumber.isEmpty()
                ? settings.getPhoneNumber()
                : pendingPhoneNumber;
        databaseHelper.updateSmsSettings(currentUserId, phoneNumber, granted);
        pendingPhoneNumber = "";

        Toast.makeText(
                this,
                granted ? "SMS reminders enabled" : "Permission denied; SMS reminders remain off",
                Toast.LENGTH_SHORT).show();
        updateSmsStatusText();
        if (granted) {
            evaluateGoalAlert();
        }
    }

    private void evaluateGoalAlert() {
        if (currentUserId == NO_ID) {
            return;
        }

        List<WeightRecord> records = databaseHelper.getWeightRecords(currentUserId, 1);
        if (records.isEmpty()) {
            return;
        }

        WeightRecord currentRecord = records.get(0);
        UserSettings settings = databaseHelper.getUserSettings(currentUserId);
        if (currentRecord.getWeight() > settings.getGoalWeight()) {
            if (settings.isGoalAlertSent()) {
                databaseHelper.setGoalAlertSent(currentUserId, false);
            }
            return;
        }

        // The alert is sent only once per goal unless the user moves above the goal again.
        if (settings.isGoalAlertSent()
                || !settings.isSmsEnabled()
                || settings.getPhoneNumber().isEmpty()
                || !SmsNotifier.canSend(this)) {
            return;
        }

        try {
            SmsNotifier.sendGoalReached(
                    this,
                    settings.getPhoneNumber(),
                    currentRecord.getWeight(),
                    settings.getGoalWeight());
            databaseHelper.setGoalAlertSent(currentUserId, true);
            Toast.makeText(this, "Goal reached SMS sent", Toast.LENGTH_LONG).show();
        } catch (RuntimeException exception) {
            Toast.makeText(
                    this,
                    "Goal reached, but SMS could not be sent on this device",
                    Toast.LENGTH_LONG).show();
        }
    }

    private TextView createTableCell(String value, int widthDp, int gravity, boolean bold) {
        TextView cell = new TextView(this);
        cell.setText(value);
        cell.setTextSize(14);
        cell.setTextColor(getColor(R.color.ink));
        cell.setGravity(gravity);
        cell.setPadding(dp(8), dp(10), dp(8), dp(10));
        cell.setBackgroundResource(R.drawable.table_cell);
        cell.setLayoutParams(new TableRow.LayoutParams(dp(widthDp), dp(58)));
        if (bold) {
            cell.setTypeface(getResources().getFont(R.font.inter_bold), Typeface.BOLD);
        }
        return cell;
    }

    private ImageButton createTableActionButton(int iconResource, String description, int widthDp) {
        ImageButton button = createActionButton(iconResource, description);
        button.setLayoutParams(new TableRow.LayoutParams(dp(widthDp), dp(58)));
        button.setPadding(dp(12), dp(14), dp(12), dp(14));
        button.setBackgroundResource(R.drawable.table_cell);
        return button;
    }

    private ImageButton createActionButton(int iconResource, String description) {
        ImageButton button = new ImageButton(this);
        button.setImageResource(iconResource);
        button.setContentDescription(description);
        button.setBackgroundColor(getColor(android.R.color.transparent));
        button.setPadding(dp(8), dp(8), dp(8), dp(8));
        button.setLayoutParams(new LinearLayout.LayoutParams(dp(44), dp(44)));
        return button;
    }

    private TextView createBodyText(String value) {
        TextView textView = new TextView(this);
        textView.setText(value);
        textView.setTextColor(getColor(R.color.muted_ink));
        textView.setTextSize(16);
        return textView;
    }

    private void configurePasswordToggle(EditText editText, ImageButton toggleButton) {
        final boolean[] visible = {false};
        toggleButton.setOnClickListener(view -> {
            visible[0] = !visible[0];
            editText.setInputType(InputType.TYPE_CLASS_TEXT | (visible[0]
                    ? InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                    : InputType.TYPE_TEXT_VARIATION_PASSWORD));
            editText.setSelection(editText.getText().length());
            toggleButton.setImageResource(visible[0]
                    ? R.drawable.ic_visibility_off
                    : R.drawable.ic_visibility);
            toggleButton.setContentDescription(visible[0]
                    ? "Hide password"
                    : "Show password");
        });
    }

    private void showAppMenu() {
        String[] menuItems = {
                "Add Weight Record",
                "Weight History",
                "SMS Reminders",
                "Log Out"
        };
        new AlertDialog.Builder(this)
                .setTitle("Weight Progress")
                .setItems(menuItems, (dialog, which) -> {
                    switch (which) {
                        case 0:
                            showAddWeightScreen(NO_ID);
                            break;
                        case 1:
                            showHistoryScreen();
                            break;
                        case 2:
                            showSmsPermissionScreen();
                            break;
                        case 3:
                            confirmLogout();
                            break;
                        default:
                            break;
                    }
                })
                .show();
    }

    private void confirmLogout() {
        new AlertDialog.Builder(this)
                .setTitle("Log out?")
                .setMessage("You can sign back in with your email and password.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Log Out", (dialog, which) -> logout())
                .show();
    }

    private void logout() {
        currentUserId = NO_ID;
        editingRecordId = NO_ID;
        pendingPhoneNumber = "";
        Toast.makeText(this, "Logged out", Toast.LENGTH_SHORT).show();
        showLoginScreen();
    }

    private static boolean isValidEmail(String value) {
        return value != null && Patterns.EMAIL_ADDRESS.matcher(value).matches();
    }

    private static boolean isValidPassword(String value) {
        if (value == null || value.length() < 8) {
            return false;
        }
        boolean hasLetter = false;
        boolean hasDigit = false;
        for (int index = 0; index < value.length(); index++) {
            char character = value.charAt(index);
            hasLetter = hasLetter || Character.isLetter(character);
            hasDigit = hasDigit || Character.isDigit(character);
        }
        return hasLetter && hasDigit;
    }

    private static String normalizeEmail(String value) {
        return value == null ? "" : value.trim().toLowerCase(Locale.US);
    }

    private static String normalizePhoneNumber(String value) {
        return value == null ? "" : value.trim().replaceAll("[\\s()-]", "");
    }

    private static boolean isValidPhoneNumber(String value) {
        return value.matches("\\+?[0-9]{7,15}");
    }

    private static String formatWeight(double value) {
        if (Math.abs(value - Math.rint(value)) < 0.0001) {
            return String.format(Locale.US, "%.0f", value);
        }
        return String.format(Locale.US, "%.1f", value);
    }

    private static String formatSignedWeight(double value) {
        if (Math.abs(value) < 0.0001) {
            return "0 lbs";
        }
        return String.format(
                Locale.US,
                "%s%s lbs",
                value > 0 ? "+" : "",
                formatWeight(value));
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void requireLoggedInUser() {
        if (currentUserId == NO_ID) {
            throw new IllegalStateException("A logged-in user is required for this screen");
        }
    }

    private void handleBackNavigation() {
        switch (currentScreen) {
            case CREATE_ACCOUNT:
                showLoginScreen();
                break;
            case HISTORY:
            case ADD_WEIGHT:
            case SMS:
                showHomeScreen();
                break;
            case HOME:
                showLoginScreen();
                break;
            case LOGIN:
            default:
                finish();
                break;
        }
    }
}
