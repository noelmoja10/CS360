package com.example.weighttracker.util;

import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Base64;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

public final class PasswordUtils {
    private static final int SALT_LENGTH_BYTES = 16;
    private static final int ITERATIONS = 65_536;
    private static final int KEY_LENGTH_BITS = 256;

    private PasswordUtils() {
    }

    public static String createSalt() {
        byte[] salt = new byte[SALT_LENGTH_BYTES];
        new SecureRandom().nextBytes(salt);
        return Base64.getEncoder().encodeToString(salt);
    }

    public static String hashPassword(String password, String encodedSalt) {
        char[] passwordCharacters = password.toCharArray();
        byte[] salt = Base64.getDecoder().decode(encodedSalt);
        PBEKeySpec specification = new PBEKeySpec(
                passwordCharacters,
                salt,
                ITERATIONS,
                KEY_LENGTH_BITS);

        try {
            SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
            byte[] hash = factory.generateSecret(specification).getEncoded();
            return Base64.getEncoder().encodeToString(hash);
        } catch (Exception exception) {
            throw new IllegalStateException("Unable to secure password", exception);
        } finally {
            specification.clearPassword();
            java.util.Arrays.fill(passwordCharacters, '\0');
        }
    }

    public static boolean verifyPassword(String password, String encodedSalt, String encodedHash) {
        byte[] expected = Base64.getDecoder().decode(encodedHash);
        byte[] actual = Base64.getDecoder().decode(hashPassword(password, encodedSalt));
        return MessageDigest.isEqual(expected, actual);
    }
}
