package com.example.weighttracker.util;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;

import java.util.Locale;

public final class SmsNotifier {
    private SmsNotifier() {
    }

    public static boolean canSend(Context context) {
        return context.checkSelfPermission(Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;
    }

    public static void sendGoalReached(
            Context context,
            String phoneNumber,
            double currentWeight,
            double goalWeight) {
        if (!canSend(context)) {
            throw new SecurityException("SMS permission has not been granted");
        }

        SmsManager smsManager = context.getSystemService(SmsManager.class);
        if (smsManager == null) {
            throw new IllegalStateException("SMS service is not available on this device");
        }

        String message = String.format(
                Locale.US,
                "Weight Progress: Congratulations! Your current weight is %.1f lbs, "
                        + "which meets your %.1f lb goal.",
                currentWeight,
                goalWeight);
        smsManager.sendTextMessage(phoneNumber, null, message, null, null);
    }
}
