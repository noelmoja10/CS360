package com.example.weighttracker.util;

import static org.junit.Assert.assertEquals;

import java.time.format.DateTimeParseException;

import org.junit.Test;

public class DateUtilsTest {
    @Test
    public void convertsDisplayDateToIsoAndBack() {
        assertEquals("2026-06-19", DateUtils.normalizeToIso("06/19/2026"));
        assertEquals("06/19/2026", DateUtils.formatForDisplay("2026-06-19"));
    }

    @Test(expected = DateTimeParseException.class)
    public void rejectsInvalidCalendarDate() {
        DateUtils.normalizeToIso("02/30/2026");
    }
}
