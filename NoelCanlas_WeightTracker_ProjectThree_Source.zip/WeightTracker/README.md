# Weight Progress - CS 360 Project Three

Weight Progress is a functional Java Android app for tracking daily weight and progress toward a goal. The interface follows the Project Two Canva design and uses the bundled Inter typeface.

## Quick Start

1. Open this folder in Android Studio.
2. Run the `app` configuration on an Android 8.0 (API 26) or newer device.
3. On the login screen, enter a new username of at least three characters and a password of at least six characters, then select **Create New Login**.
4. Add a weight from the dashboard or open **Goal** to enter a weight, date, goal, and optional note.
5. Open **History** to update or delete individual records.
6. Open **Settings** to test SMS permission. Denying the permission does not disable any weight-tracking feature.

No account is preloaded. Account creation is part of the required login workflow.

## Rubric Coverage

- **Log In:** Creates accounts, stores salted PBKDF2 password hashes, validates credentials against SQLite, obscures password entry, and rejects duplicate usernames.
- **Database:** Uses persistent SQLite tables for users, settings, and weight records. The history grid supports create, read, update, and delete operations with duplicate-date validation.
- **SMS Notifications:** Declares `SEND_SMS`, requests it at runtime, stores the user's choice, sends a one-time goal-reached alert when allowed, and keeps the app functional after denial.
- **Coding Best Practices:** Separates database, model, date, password, and SMS responsibilities; uses clear naming, parameterized queries, transactions, and focused comments.
- **Visual Design:** Preserves the dark green, white, and gray Project Two system; uses Inter typography, consistent controls, logical focus order, and labeled icon actions.

## Build Verification

Run these commands from the project root:

```bash
./gradlew :app:assembleDebug
./gradlew :app:testDebugUnitTest
./gradlew :app:lintDebug
```

The generated debug APK is located at `app/build/outputs/apk/debug/app-debug.apk`.

## Device Notes

SMS delivery requires a device or emulator with telephony support. On devices without telephony, all login, database, history, and progress features still work. The app supports API 26 through target API 36.

## Typeface

Inter 4.1 is bundled in `app/src/main/res/font`. Its license is included in `INTER_LICENSE.txt`.
