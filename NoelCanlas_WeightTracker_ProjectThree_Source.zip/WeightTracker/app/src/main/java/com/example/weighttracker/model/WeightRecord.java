package com.example.weighttracker.model;

public final class WeightRecord {
    private final long id;
    private final long userId;
    private final String entryDate;
    private final double weight;
    private final String notes;

    public WeightRecord(long id, long userId, String entryDate, double weight, String notes) {
        this.id = id;
        this.userId = userId;
        this.entryDate = entryDate;
        this.weight = weight;
        this.notes = notes == null ? "" : notes;
    }

    public long getId() {
        return id;
    }

    public long getUserId() {
        return userId;
    }

    public String getEntryDate() {
        return entryDate;
    }

    public double getWeight() {
        return weight;
    }

    public String getNotes() {
        return notes;
    }
}
